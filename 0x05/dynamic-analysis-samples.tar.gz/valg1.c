#include <stdio.h>

int main()
{
  int* p;
  int c = *p;
  if (0 == c)
  {
    printf("Kuku!!!\n");
  }
  return 0;
}
