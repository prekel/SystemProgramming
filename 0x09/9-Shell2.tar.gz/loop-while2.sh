#!/bin/sh
INPUT_STRING=hello
while :
do
    echo "Type something here [Ctrl-C to quit]"
    read INPUT_STRING
    echo "You've typed $INPUT_STRING"
    
done

exit 0
