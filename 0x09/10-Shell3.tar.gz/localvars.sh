#!/bin/sh

func()
{
  local loc_var=23       # local variable declaration
  echo
  echo "\"loc_var\" inside the function = $loc_var"
  global_var=999         # global variable declaration
  echo "\"global_var\" inside the function = $global_var"
}

func

# Check if local variable is visible outside the function

echo
echo "\"loc_var\" outside the function = $loc_var"
# "loc_var" outside the function =
# So, $loc_var invisible in global context

echo "\"global_var\" outside the function = $global_var"
# "global_var" outside the function = 999
# $global_var has global scope

echo                                  

exit 0