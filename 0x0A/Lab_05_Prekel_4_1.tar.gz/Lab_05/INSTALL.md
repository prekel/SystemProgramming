# Lab_05

## Инсталляция

```shell script
sudo make install
```

После инсталляции можно запускать сервер и клиент напрямую:

```shell script
Lab_05_Server
Lab_05_Client
```

## Деинсталляция

```shell script
sudo make uninstall
```
