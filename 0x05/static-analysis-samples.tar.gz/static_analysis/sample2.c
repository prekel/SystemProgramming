#include <stdio.h>

int main()
{
  int* fp = malloc(sizeof (int));

  return 0;
}
