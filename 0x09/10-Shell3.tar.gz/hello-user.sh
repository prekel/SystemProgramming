#!/bin/sh

hello () { echo "hello, $1"; }

hello abrakadabra

exit 0
