#ifndef LINKEDLISTTESTS_H
#define LINKEDLISTTESTS_H

#include <CUnit/Basic.h>

CU_pSuite* LinkedListTestsSuiteCreate();

void LinkedListTest_Create1(void);

void LinkedListTest_Append1(void);

void LinkedListTest_Append2(void);

#endif //LINKEDLISTTESTS_H
