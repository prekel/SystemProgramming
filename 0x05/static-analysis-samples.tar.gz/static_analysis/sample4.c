#include <stdio.h>

int main()
{
  int a = 0;
  int f = 1/a;
  
  printf("%d\n", f);
  return 0;
}
