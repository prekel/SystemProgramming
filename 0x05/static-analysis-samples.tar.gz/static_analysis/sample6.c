#include <stdio.h>
#include <stdlib.h>

int main()
{
  int a[10] = { NULL };
  
  printf("%d\n", a[10]);
  return 0;
}
