#!/bin/sh

factorial()
{
  local k
  
  if [ "$1" -gt "1" ]; then
    i=`expr $1 - 1`
    factorial $i
    j=$?
    k=`expr $1 \* $j`
  else
    k=1
  fi
  return $k
}


while :
do
  echo "Enter a number:"
  read x
  [ $x -lt 0 ] && echo "Wrong number! Repeat, please!" && continue
  factorial $x
  echo $?
done

echo                                  

exit 0