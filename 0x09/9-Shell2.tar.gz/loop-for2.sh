#!/bin/sh
for i in hello 2 * 3 5 7 goodbye and farewell
do
    echo $i
done

exit 0
