#!/bin/sh

echo "$@"
shift 4
echo "$@"

exit 0