#!/bin/sh
# This is a comment!
echo Hello World        # This is a comment, too!