#!/bin/sh

myfunc()
{
  a="Goodbye Cruel"
}

### Main script starts here 

echo "before myfunc a is $a"

myfunc

echo "after myfunc a is $a"

exit 0
