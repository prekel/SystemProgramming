#include <stdio.h>

int main()
{
  FILE* fp = fopen("kuku", "r");

  return 0;
}
