#!/bin/sh
for i in 1 2 3 5 7
do
    echo $i
done

exit 0
