#!/bin/sh

# Manipulating a variable, C-style, using the (( ... )) construct.
echo
(( a = 23 )) # Setting a value, C-style,
#+ with spaces on both sides of the "=".
echo "a (initial value) = $a" # 23
(( a++ )) # Post-increment 'a', C-style.
echo "a (after a++) = $a" # 24
(( a-- )) # Post-decrement 'a', C-style.
echo "a (after a--) = $a" # 23
(( ++a )) # Pre-increment 'a', C-style.
echo "a (after ++a) = $a" # 24
(( --a )) # Pre-decrement 'a', C-style.
echo "a (after --a) = $a" # 23

echo

n=1; let --n && echo "True" || echo "False" # False
n=1; let n-- && echo "True" || echo "False" # True

echo
(( t = a<45?7:11 )) # C-style trinary operator.
# ^ ^ ^
echo "If a < 45, then t = 7, else t = 11." # a = 23
echo "t = $t " # t = 7
echo

exit 0
