#!/bin/sh

a=letter
letter=z

echo "a = $a"

echo "Now a = ${!a}"

echo
exit 0
