/*
 * Simple Informative/Automated Test interface
 */

#ifndef CU_SIMPLE_H
#define CU_SIMPLE_H

#endif //CU_SIMPLE_H
