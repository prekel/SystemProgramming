#!/bin/sh
# function1.sh
. ./common.lib
echo $STD_MSG
rename txt bak

exit 0