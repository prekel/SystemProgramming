#!/bin/sh

factorial()
{
  if [ "$1" -gt "1" ]; then
    i=`expr $1 - 1`
    j=`factorial $i`
    k=`expr $1 \* $j`
    echo $k
  else
    echo 1
  fi
}


while :
do
  echo "Enter a number:"
  read x
  [ $x -lt 0 ] && echo "Wrong number! Repeat, please!" && continue
  factorial $x
done

echo                                  

exit 0