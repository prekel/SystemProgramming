#!/bin/sh
MY_MESSAGE="Hello World"
echo $MY_MESSAGE