#!/bin/sh
# function2.sh
. ./common.lib
echo $STD_MSG
rename html html-bak

exit 0