#ifndef ARCHIPELAGOCOLLECTIONTESTS_H
#define ARCHIPELAGOCOLLECTIONTESTS_H

#include <CUnit/Basic.h>

CU_pSuite* ArchipelagoCollectionTestsSuiteCreate();

void ArchipelagoCollectionTest_Add1(void);

#endif //ARCHIPELAGOCOLLECTIONTESTS_H
