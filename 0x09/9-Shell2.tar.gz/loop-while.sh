#!/bin/sh
INPUT_STRING=hello
while [ "$INPUT_STRING" != "bye" ]
do
    echo "Type something here [bye to quit]"
    read INPUT_STRING
    echo "You've typed $INPUT_STRING"
    
done

exit 0
