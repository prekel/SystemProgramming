#!/bin/sh

a=letter
letter=z

# Direct reference
echo "a = $a"

# Indirect reference
eval a=\$$a
echo "a = $a"

echo
exit 0
